// This function will run whenever a region is selected
document.getElementById('region-select').addEventListener('change', function() {
    const region = this.value;
    const content = document.getElementById('content');

    // Dictionary to store the famous items for each region
    const regionData = {
        kutch: {
            title: 'Kutch, Gujarat - Handicrafts',
            items: [
                { img: 'handicraft.jpg', name: 'Embroidery', desc: 'Beautiful embroidered textiles and fabrics.' },
                { img: 'tie-dye.jpg', name: 'Tie-dye', desc: 'Famous for traditional tie-dye techniques.' }
            ]
        },
        jaipur: {
            title: 'Jaipur, Rajasthan - Jewelry & Block Printing',
            items: [
                { img: 'jewelry.jpg', name: 'Jewelry', desc: 'Create your own handcrafted jewelry.' },
                { img: 'block-print.jpg', name: 'Block Printed Fabrics', desc: 'Jaipur’s famous block-printed sarees and fabrics.' }
            ]
        },
        kochi: {
            title: 'Kochi, Kerala - Spices',
            items: [
                { img: 'spices.jpg', name: 'Organic Spices', desc: 'Package and sell high-quality organic spices.' }
            ]
        },
        lucknow: {
            title: 'Lucknow, Uttar Pradesh - Chikan Embroidery',
            items: [
                { img: 'chikan.jpg', name: 'Chikan Embroidery', desc: 'Create beautiful Chikan-embroidered garments.' }
            ]
        },
        darjeeling: {
            title: 'Darjeeling, West Bengal - Organic Tea',
            items: [
                { img: 'tea.jpg', name: 'Tea Packaging', desc: 'Package and brand Darjeeling’s famous tea.' }
            ]
        },
        manipur: {
            title: 'Manipur - Handloom Products',
            items: [
                { img: 'handloom.jpg', name: 'Handloom Weaving', desc: 'Weave traditional Manipuri textiles.' }
            ]
        },
        assam: {
            title: 'Assam - Bamboo & Cane Products',
            items: [
                { img: 'bamboo.jpg', name: 'Bamboo Products', desc: 'Create eco-friendly bamboo and cane products.' }
            ]
        },
        mysore: {
            title: 'Mysore, Karnataka - Sandalwood & Incense',
            items: [
                { img: 'incense.jpg', name: 'Incense Sticks', desc: 'Produce natural incense sticks and sandalwood products.' }
            ]
        },
        sundarbans: {
            title: 'Sundarbans, West Bengal - Organic Honey',
            items: [
                { img: 'honey.jpg', name: 'Organic Honey', desc: 'Harvest and sell organic honey.' }
            ]
        },
        bhubaneswar: {
            title: 'Bhubaneswar, Odisha - Applique Work',
            items: [
                { img: 'applique.jpg', name: 'Applique Work', desc: 'Create unique home decor with Pipli’s famous applique work.' }
            ]
        },
        srinagar: {
            title: 'Srinagar, Kashmir - Pashmina Shawls',
            items: [
                { img: 'pashmina.jpg', name: 'Pashmina Shawls', desc: 'Create or resell luxurious Pashmina shawls.' }
            ]
        },
        punjab: {
            title: 'Punjab - Pickle Making',
            items: [
                { img: 'pickle.jpg', name: 'Pickles', desc: 'Start a small pickle-making business using traditional recipes.' }
            ]
        },
        tamilnadu: {
            title: 'Tamil Nadu - Silk Sarees',
            items: [
                { img: 'silk.jpg', name: 'Silk Sarees', desc: 'Sell or design authentic Kanchipuram silk sarees.' }
            ]
        }
    };

    // Check if the selected region exists in the data
    if (regionData[region]) {
        const regionInfo = regionData[region];
        let htmlContent = `<h2>${regionInfo.title}</h2><div class="grid-container">`;

        // Loop through the items for the selected region and generate HTML
        regionInfo.items.forEach(item => {
            htmlContent += `
                <div class="card">
                    <img src="${item.img}" alt="${item.name}">
                    <h3>${item.name}</h3>
                    <p>${item.desc}</p>
                </div>`;
        });

        htmlContent += '</div>';

        // Update the content area with the new HTML
        content.innerHTML = htmlContent;
    } else {
        content.innerHTML = '<h2>Select a region to see what is famous for small-scale business opportunities</h2>';
    }
});
